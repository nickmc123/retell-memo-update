const axios = require('axios');

const API_KEY = 'key_7148b1d34413c4639232d5bdc836';

async function fetchAgents() {
    try {
        // List all agents - try different endpoints
        const endpoints = [
            'https://api.retellai.com/list-agents',
            'https://api.retellai.com/v2/agent',
            'https://api.retellai.com/agent'
        ];

        let response = null;
        for (const endpoint of endpoints) {
            try {
                console.log(`Trying endpoint: ${endpoint}`);
                response = await axios.get(endpoint, {
                    headers: {
                        'Authorization': `Bearer ${API_KEY}`
                    }
                });
                console.log(`✅ Success with: ${endpoint}\n`);
                break;
            } catch (err) {
                console.log(`❌ Failed: ${endpoint}`);
                continue;
            }
        }

        if (!response) {
            console.log('\nAll endpoints failed. Let me try listing custom tools instead:');

            const toolResponse = await axios.get('https://api.retellai.com/list-custom-tools', {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`
                }
            });

            console.log('Custom Tools:');
            console.log(JSON.stringify(toolResponse.data, null, 2));

            // Look for Search-customer-data tool
            const tools = toolResponse.data.tools || toolResponse.data;
            const searchTool = tools.find(t => t.tool_name && t.tool_name.includes('Search-customer-data'));

            if (searchTool) {
                console.log('\n\n=== Found Tool: Search-customer-data ===');
                console.log(JSON.stringify(searchTool, null, 2));
            }

            return;
        }

        console.log('All Agents:');
        console.log(JSON.stringify(response.data, null, 2));

    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
    }
}

fetchAgents();
