const axios = require('axios');

const API_KEY = 'key_7148b1d34413c4639232d5bdc836';
const FLOW_ID = 'conversation_flow_317edc0826db';

async function fetchFlow() {
    try {
        console.log(`Fetching conversation flow: ${FLOW_ID}\n`);

        const response = await axios.get(`https://api.retellai.com/get-conversation-flow/${FLOW_ID}`, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`
            }
        });

        console.log('Full Flow:');
        console.log(JSON.stringify(response.data, null, 2));

        // Look for tools in the flow
        if (response.data.tools) {
            console.log('\n\n=== Tools in Flow ===');
            response.data.tools.forEach((tool, idx) => {
                console.log(`\nTool ${idx + 1}: ${tool.name || tool.tool_name}`);
                console.log(JSON.stringify(tool, null, 2));
            });

            // Find Search-customer-data specifically
            const searchTool = response.data.tools.find(t =>
                (t.name && t.name.includes('Search-customer-data')) ||
                (t.tool_name && t.tool_name.includes('Search-customer-data'))
            );

            if (searchTool) {
                console.log('\n\n=== Search-customer-data Tool Specification ===');
                console.log(JSON.stringify(searchTool, null, 2));
            }
        }

        // Also check for tools in nodes
        if (response.data.nodes) {
            console.log('\n\n=== Checking Nodes for Function Tools ===');
            response.data.nodes.forEach((node, idx) => {
                if (node.type === 'function' && node.tool_id) {
                    console.log(`\nNode ${idx + 1} (${node.name}): tool_id = ${node.tool_id}`);
                }
            });
        }

    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
        if (error.response?.status === 404) {
            console.log('\nFlow not found. Let me try listing all custom tools:');

            try {
                const toolsResponse = await axios.get('https://api.retellai.com/list-custom-tools', {
                    headers: {
                        'Authorization': `Bearer ${API_KEY}`
                    }
                });

                console.log('\nAll Custom Tools:');
                console.log(JSON.stringify(toolsResponse.data, null, 2));
            } catch (err) {
                console.error('Error listing tools:', err.message);
            }
        }
    }
}

fetchFlow();
