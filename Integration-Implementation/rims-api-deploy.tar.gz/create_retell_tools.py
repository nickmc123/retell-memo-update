#!/usr/bin/env python3
"""
Create Retell AI Tools for RIMS Integration
"""

import requests
import json
import sys

API_KEY = "key_7148b1d34413c4639232d5bdc836"
API_URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000"

print("🚀 Creating Retell AI Tools for RIMS Integration")
print("=" * 60)
print(f"API URL: {API_URL}\n")

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

tools = [
    {
        "name": "rims_phone_lookup",
        "tool_name": "rims_phone_lookup",
        "description": "Look up customer in RIMS database by phone number. Searches both primary (phn1) and secondary (phn2) phone fields. Returns all customer data including vac_id, certificate info, deposits, travel dates, and Travel Rep assignment.",
        "url": f"{API_URL}/api/rims/phone-lookup",
        "method": "POST",
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"phone_number": "{{phone_number}}"}),
        "parameters": [
            {
                "name": "phone_number",
                "type": "string",
                "description": "Customer phone number (10 digits, any format accepted)",
                "required": True
            }
        ]
    },
    {
        "name": "rims_certificate_lookup",
        "tool_name": "rims_certificate_lookup",
        "description": "Look up customer in RIMS database by certificate number (pkg_code2 field). Returns all customer data including contact info, deposits, travel dates, and booking status.",
        "url": f"{API_URL}/api/rims/certificate-lookup",
        "method": "POST",
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"certificate_number": "{{certificate_number}}"}),
        "parameters": [
            {
                "name": "certificate_number",
                "type": "string",
                "description": "Certificate number from customer (e.g., ECFWIN, BEACH123)",
                "required": True
            }
        ]
    },
    {
        "name": "deposits_check",
        "tool_name": "deposits_check",
        "description": "Check if customer deposits are complete by comparing paid amount (val_dep + conf_deposit) against expected deposit from Knowledge Base. Returns status (complete/partial/no_deposits) and next action (transfer_extension_1/provide_payment_info/direct_to_website).",
        "url": f"{API_URL}/api/logic/deposits-check",
        "method": "POST",
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"customer_data": "{{customer_data}}"}),
        "parameters": [
            {
                "name": "customer_data",
                "type": "object",
                "description": "Customer data object from phone_lookup or certificate_lookup (must include pkg_code, val_dep, conf_deposit)",
                "required": True
            }
        ]
    },
    {
        "name": "travel_rep_check",
        "tool_name": "travel_rep_check",
        "description": "Check Travel Rep assignment status. Implements 45-75 day window logic: if travel date is within 45 days and no TR assigned, status=needs_tr_urgent. If TR assigned but docs not sent (date_print_enc blank), status=tr_needs_to_call. Returns appropriate memo creation instructions.",
        "url": f"{API_URL}/api/logic/travel-rep-check",
        "method": "POST",
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"customer_data": "{{customer_data}}"}),
        "parameters": [
            {
                "name": "customer_data",
                "type": "object",
                "description": "Customer data object from lookup (must include Asgn_trv_DT, tm, date_print_enc, confirm_status)",
                "required": True
            }
        ]
    },
    {
        "name": "create_rims_memo",
        "tool_name": "create_rims_memo",
        "description": "Create a memo in RIMS_MEMOS table for staff follow-up. Memo types: needs tr assignment (urgent TR needed), ask tr to call (TR assigned but docs not sent), resend itinerary (customer needs itinerary resent). Memos are created by AI Agent and timestamped.",
        "url": f"{API_URL}/api/memos/create",
        "method": "POST",
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "memo_type": "{{memo_type}}",
            "details": "{{details}}",
            "vac_id": "{{vac_id}}",
            "phone_number": "{{phone_number}}"
        }),
        "parameters": [
            {
                "name": "memo_type",
                "type": "string",
                "description": "Type of memo: needs tr assignment, ask tr to call, or resend itinerary",
                "required": True
            },
            {
                "name": "details",
                "type": "string",
                "description": "Memo details (e.g., Travel date: 2025-06-15, Days remaining: 42)",
                "required": False
            },
            {
                "name": "vac_id",
                "type": "string",
                "description": "Customer vac_id from RIMS database",
                "required": True
            },
            {
                "name": "phone_number",
                "type": "string",
                "description": "Customer phone number",
                "required": False
            }
        ]
    }
]

tool_ids = []

for i, tool in enumerate(tools, 1):
    print(f"📞 Creating Tool {i}: {tool['name']}...")

    try:
        response = requests.post(
            "https://api.retellai.com/v2/create-custom-tool",
            headers=headers,
            json=tool
        )

        if response.status_code == 200 or response.status_code == 201:
            result = response.json()
            tool_id = result.get('tool_id', 'UNKNOWN')
            tool_ids.append((tool['name'], tool_id))
            print(f"✅ Tool {i} ID: {tool_id}\n")
        else:
            print(f"❌ Error creating tool {i}:")
            print(f"   Status: {response.status_code}")
            print(f"   Response: {response.text}\n")
            tool_ids.append((tool['name'], "ERROR"))
    except Exception as e:
        print(f"❌ Exception creating tool {i}: {str(e)}\n")
        tool_ids.append((tool['name'], "ERROR"))

print("=" * 60)
print("📋 Tool IDs Summary:")
print()
for name, tool_id in tool_ids:
    print(f"   {name:30} {tool_id}")
print()
print("=" * 60)
print()
print("🔗 Next Steps:")
print("   1. Add these tool IDs to your Retell AI agent")
print("   2. Deploy your API to production (Railway/Render)")
print("   3. Re-run this script with production URL:")
print(f"      python3 create_retell_tools.py https://your-app.railway.app")
print()
