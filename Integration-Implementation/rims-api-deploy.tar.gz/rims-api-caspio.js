/**
 * Casablanca Express - RIMS Database API (Caspio Integration)
 * For Retell AI Agent Integration
 *
 * Uses Caspio REST API with OAuth 2.0 authentication
 */

const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const USE_MOCK_DATA = process.env.USE_MOCK_DATA === 'true';

// =============================================================================
// CASPIO CONFIGURATION
// =============================================================================

const CASPIO_CONFIG = {
    accountId: process.env.CASPIO_ACCOUNT_ID || 'c3afw288',
    baseUrl: process.env.CASPIO_BASE_URL || 'https://c3afw288.caspio.com',
    tokenUrl: process.env.CASPIO_TOKEN_URL || 'https://c3afw288.caspio.com/oauth/token',
    clientId: process.env.CASPIO_CLIENT_ID,
    clientSecret: process.env.CASPIO_CLIENT_SECRET,

    // Table names (update these to match your actual Caspio table names)
    tables: {
        rims_data: process.env.CASPIO_TABLE_RIMS || 'RIMS_DATA',
        knowledge_base: process.env.CASPIO_TABLE_KB || 'Knowledge_Base',
        rims_memos: process.env.CASPIO_TABLE_MEMOS || 'RIMS_MEMOS'
    }
};

// OAuth token cache
let cachedToken = null;
let tokenExpiry = null;

// =============================================================================
// MOCK DATA - RIMS_DATA Structure
// =============================================================================

const MOCK_RIMS_DATA = [
    {
        phn1: "8182121359",
        phn2: "3105551234",
        pkg_code: "BEACH",
        pkg_code2: "BEACH123",
        vac_id: "123456",
        last_name: "Johnson",
        first_name: "Sarah",
        email: "sarah.johnson@email.com",
        val_dep: 250.00,
        conf_deposit: 500.00,
        Asgn_trv_DT: "2025-06-15",
        confirm_status: "confirm",
        tm: "John Smith",
        date_print_enc: "2025-05-01",
        agency_book_via: "FLIGHT123",
        htl_bk_via: "HOTEL456"
    },
    {
        phn1: "3105559876",
        phn2: "",
        pkg_code: "E",
        pkg_code2: "E789",
        vac_id: "234567",
        last_name: "Chen",
        first_name: "Mike",
        email: "mike.chen@email.com",
        val_dep: 250.00,
        conf_deposit: 250.00,
        Asgn_trv_DT: "2025-01-26",
        confirm_status: "confirm",
        tm: "",
        date_print_enc: "",
        agency_book_via: "",
        htl_bk_via: ""
    },
    {
        phn1: "4155551212",
        phn2: "",
        pkg_code: "SKI",
        pkg_code2: "SKI555",
        vac_id: "345678",
        last_name: "Martinez",
        first_name: "Lisa",
        email: "lisa.martinez@email.com",
        val_dep: 0,
        conf_deposit: 0,
        Asgn_trv_DT: "2025-08-15",
        confirm_status: "confirm",
        tm: "",
        date_print_enc: "",
        agency_book_via: "",
        htl_bk_via: ""
    }
];

// Hardcoded Knowledge Base - Deposit amounts only
// (Package descriptions are in Retell AI Knowledge Base)
const MOCK_KNOWLEDGE_BASE = {
    // ECF packages
    "ECF": { total_deposit: 500, activation_method: "online" },
    "ECFWIN": { total_deposit: 500, activation_method: "online" },

    // E packages
    "E": { total_deposit: 500, activation_method: "online" },
    "E7": { total_deposit: 500, activation_method: "online" },
    "E78": { total_deposit: 500, activation_method: "online" },
    "E789": { total_deposit: 500, activation_method: "online" },

    // BEACH packages
    "BEACH": { total_deposit: 750, activation_method: "online" },
    "BEACH1": { total_deposit: 750, activation_method: "online" },
    "BEACH12": { total_deposit: 750, activation_method: "online" },
    "BEACH123": { total_deposit: 750, activation_method: "online" },

    // SKI packages
    "SKI": { total_deposit: 800, activation_method: "mail" },
    "SKI5": { total_deposit: 800, activation_method: "mail" },
    "SKI55": { total_deposit: 800, activation_method: "mail" },
    "SKI555": { total_deposit: 800, activation_method: "mail" },

    // Add more package codes as needed
};

const MOCK_MEMOS = [];

// Middleware
app.use(cors());
app.use(express.json());

// Logging middleware
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// Error handling middleware
const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
};

// =============================================================================
// CASPIO API CLIENT
// =============================================================================

/**
 * Get OAuth access token (cached)
 */
async function getCaspioToken() {
    // Return cached token if still valid
    if (cachedToken && tokenExpiry && Date.now() < tokenExpiry) {
        return cachedToken;
    }

    try {
        const credentials = Buffer.from(`${CASPIO_CONFIG.clientId}:${CASPIO_CONFIG.clientSecret}`).toString('base64');

        const response = await axios.post(
            CASPIO_CONFIG.tokenUrl,
            'grant_type=client_credentials',
            {
                headers: {
                    'Authorization': `Basic ${credentials}`,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        cachedToken = response.data.access_token;
        // Set expiry to 5 minutes before actual expiry for safety
        tokenExpiry = Date.now() + ((response.data.expires_in - 300) * 1000);

        console.log('✅ Caspio OAuth token obtained');
        return cachedToken;
    } catch (error) {
        console.error('❌ Caspio OAuth error:', error.response?.data || error.message);
        throw new Error('Failed to authenticate with Caspio');
    }
}

/**
 * Query Caspio table
 */
async function queryCaspioTable(tableName, whereClause = null) {
    const token = await getCaspioToken();

    const url = `${CASPIO_CONFIG.baseUrl}/rest/v2/tables/${tableName}/records`;
    const params = {};

    if (whereClause) {
        params['q.where'] = whereClause;
    }

    try {
        const response = await axios.get(url, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            },
            params
        });

        return response.data.Result || [];
    } catch (error) {
        console.error(`❌ Caspio query error (${tableName}):`, error.response?.data || error.message);
        throw new Error(`Failed to query ${tableName}`);
    }
}

/**
 * Insert record into Caspio table
 */
async function insertCaspioRecord(tableName, data) {
    const token = await getCaspioToken();

    const url = `${CASPIO_CONFIG.baseUrl}/rest/v2/tables/${tableName}/records`;

    try {
        const response = await axios.post(url, data, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        return response.data;
    } catch (error) {
        console.error(`❌ Caspio insert error (${tableName}):`, error.response?.data || error.message);
        throw new Error(`Failed to insert into ${tableName}`);
    }
}

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function daysBetween(date1, date2) {
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round((date2 - date1) / oneDay);
}

function normalizePhone(phone) {
    return phone.replace(/\D/g, '');
}

function isDateBlank(dateStr) {
    return !dateStr || dateStr === '' || dateStr === '0000-00-00';
}

function stripCertificateCode(code) {
    const variations = [code];
    let current = code;

    while (current.length > 0 && /\d$/.test(current)) {
        current = current.slice(0, -1);
        if (current) variations.push(current);
    }

    return variations;
}

// =============================================================================
// RIMS_DATA ENDPOINTS
// =============================================================================

/**
 * POST /api/rims/phone-lookup
 * Look up customer by phone number (checks phn1 and phn2)
 */
app.post('/api/rims/phone-lookup', asyncHandler(async (req, res) => {
    const { phone_number } = req.body;

    if (!phone_number) {
        return res.status(400).json({
            error: 'Missing phone_number',
            message: 'Phone number is required'
        });
    }

    const normalized = normalizePhone(phone_number);

    // MOCK MODE
    if (USE_MOCK_DATA) {
        const customer = MOCK_RIMS_DATA.find(c =>
            normalizePhone(c.phn1) === normalized || normalizePhone(c.phn2) === normalized
        );

        if (!customer) {
            return res.json({
                found: false,
                message: 'Customer not found in RIMS database'
            });
        }

        return res.json({
            found: true,
            customer_data: customer
        });
    }

    // CASPIO MODE
    // Query: find record where phn1 or phn2 matches (Caspio uses SQL-like syntax)
    const whereClause = `phn1='${normalized}' OR phn2='${normalized}'`;

    const results = await queryCaspioTable(CASPIO_CONFIG.tables.rims_data, whereClause);

    if (results.length === 0) {
        return res.json({
            found: false,
            message: 'Customer not found in RIMS database'
        });
    }

    res.json({
        found: true,
        customer_data: results[0]
    });
}));

/**
 * POST /api/rims/certificate-lookup
 * Look up customer by certificate number (checks pkg_code2)
 */
app.post('/api/rims/certificate-lookup', asyncHandler(async (req, res) => {
    const { certificate_number } = req.body;

    if (!certificate_number) {
        return res.status(400).json({
            error: 'Missing certificate_number',
            message: 'Certificate number is required'
        });
    }

    // MOCK MODE
    if (USE_MOCK_DATA) {
        const customer = MOCK_RIMS_DATA.find(c =>
            c.pkg_code2.toUpperCase() === certificate_number.toUpperCase()
        );

        if (!customer) {
            return res.json({
                found: false,
                message: 'Certificate not found in RIMS database'
            });
        }

        return res.json({
            found: true,
            customer_data: customer
        });
    }

    // CASPIO MODE
    const whereClause = `pkg_code2='${certificate_number.toUpperCase()}'`;
    const results = await queryCaspioTable(CASPIO_CONFIG.tables.rims_data, whereClause);

    if (results.length === 0) {
        return res.json({
            found: false,
            message: 'Certificate not found in RIMS database'
        });
    }

    res.json({
        found: true,
        customer_data: results[0]
    });
}));

// =============================================================================
// KNOWLEDGE BASE ENDPOINTS
// =============================================================================

/**
 * GET /api/kb/package/:certificate_code
 * Get package deposit information (hardcoded - descriptions are in Retell KB)
 */
app.get('/api/kb/package/:certificate_code', asyncHandler(async (req, res) => {
    const { certificate_code } = req.params;

    // Try progressive stripping to find package
    const variations = stripCertificateCode(certificate_code);

    for (const variant of variations) {
        const pkg = MOCK_KNOWLEDGE_BASE[variant.toUpperCase()];
        if (pkg) {
            return res.json({
                found: true,
                certificate_code: variant,
                package_info: pkg
            });
        }
    }

    return res.status(404).json({
        found: false,
        message: `Package deposit information not found for certificate code: ${certificate_code}`,
        note: "Package descriptions are in Retell AI Knowledge Base"
    });
}));

// =============================================================================
// BUSINESS LOGIC ENDPOINTS
// =============================================================================

/**
 * POST /api/logic/deposits-check
 * Check deposit status and compare to expected amount
 */
app.post('/api/logic/deposits-check', asyncHandler(async (req, res) => {
    const { customer_data } = req.body;

    if (!customer_data) {
        return res.status(400).json({
            error: 'Missing customer_data'
        });
    }

    const val_dep = parseFloat(customer_data.val_dep) || 0;
    const conf_deposit = parseFloat(customer_data.conf_deposit) || 0;
    const total_paid = val_dep + conf_deposit;

    // Get expected deposit from KB
    const certificate_code = customer_data.pkg_code || customer_data.pkg_code2;

    // Get KB info from hardcoded knowledge base (works in both modes)
    let kb_info = null;
    const variations = stripCertificateCode(certificate_code);
    for (const variant of variations) {
        if (MOCK_KNOWLEDGE_BASE[variant.toUpperCase()]) {
            kb_info = MOCK_KNOWLEDGE_BASE[variant.toUpperCase()];
            break;
        }
    }

    const expected_deposit = kb_info ? kb_info.total_deposit : null;

    // Determine status
    let status, message, next_action;

    if (!expected_deposit) {
        // If KB info not found, return what we know
        return res.json({
            status: "unknown_package",
            message: "Package deposit amount not configured",
            deposits: {
                val_dep,
                conf_deposit,
                total_paid
            },
            note: "Add this package code to MOCK_KNOWLEDGE_BASE in the API"
        });
    }

    if (total_paid === 0) {
        status = "no_deposits";
        message = "No deposits received";
        next_action = kb_info.activation_method === "online"
            ? "direct_to_website"
            : "ask_if_mailed";
    } else if (total_paid >= expected_deposit) {
        status = "complete";
        message = "Deposits complete - ready to schedule travel";
        next_action = "transfer_extension_1";
    } else {
        status = "partial";
        const remaining = expected_deposit - total_paid;
        message = `Partial payment received. Remaining: $${remaining}`;
        next_action = "provide_payment_info";
    }

    res.json({
        status,
        message,
        next_action,
        deposits: {
            val_dep,
            conf_deposit,
            total_paid,
            expected_deposit,
            remaining: Math.max(0, expected_deposit - total_paid)
        },
        activation_method: kb_info.activation_method
    });
}));

/**
 * POST /api/logic/travel-rep-check
 * Check if Travel Rep needs to be assigned or contacted
 */
app.post('/api/logic/travel-rep-check', asyncHandler(async (req, res) => {
    const { customer_data } = req.body;

    if (!customer_data) {
        return res.status(400).json({
            error: 'Missing customer_data'
        });
    }

    const travel_date = customer_data.Asgn_trv_DT;
    const confirm_status = customer_data.confirm_status;
    const tm = customer_data.tm;
    const date_print_enc = customer_data.date_print_enc;

    if (isDateBlank(travel_date)) {
        return res.json({
            status: "no_date",
            message: "No travel date assigned yet",
            action: "none"
        });
    }

    const travelDate = new Date(travel_date);
    const today = new Date();
    const days_remaining = daysBetween(today, travelDate);

    if (days_remaining < 0) {
        return res.json({
            status: "past_date",
            message: "Travel date has passed",
            days_remaining,
            action: "none"
        });
    }

    if (confirm_status !== "confirm") {
        return res.json({
            status: "not_confirmed",
            message: "Trip not confirmed yet",
            action: "none"
        });
    }

    // TR not assigned
    if (!tm || tm === '') {
        if (days_remaining < 45) {
            return res.json({
                status: "needs_tr_urgent",
                message: `Travel date in ${days_remaining} days - Travel Rep assignment urgent`,
                days_remaining,
                action: "create_memo",
                memo_type: "needs tr assignment",
                memo_details: `Travel date: ${travel_date}, Days remaining: ${days_remaining}`
            });
        } else if (days_remaining >= 45 && days_remaining <= 75) {
            return res.json({
                status: "normal_window",
                message: `Travel date in ${days_remaining} days - normal TR assignment window`,
                days_remaining,
                action: "none"
            });
        } else {
            return res.json({
                status: "too_early",
                message: `Travel date in ${days_remaining} days - too early for TR assignment`,
                days_remaining,
                action: "none"
            });
        }
    }

    // TR assigned, check if docs sent
    if (isDateBlank(date_print_enc)) {
        return res.json({
            status: "tr_needs_to_call",
            message: `Travel Rep ${tm} assigned but hasn't sent documents`,
            travel_rep_name: tm,
            action: "create_memo",
            memo_type: "ask tr to call",
            memo_details: `Travel Rep: ${tm}, Customer: ${customer_data.phn1}`
        });
    }

    // All good - docs sent
    return res.json({
        status: "tr_complete",
        message: `Travel Rep ${tm} assigned and documents sent on ${date_print_enc}`,
        travel_rep_name: tm,
        docs_sent_date: date_print_enc,
        action: "contact_tr_directly"
    });
}));

/**
 * POST /api/logic/booking-check
 * Check if customer is booked and has itinerary
 */
app.post('/api/logic/booking-check', asyncHandler(async (req, res) => {
    const { customer_data } = req.body;

    if (!customer_data) {
        return res.status(400).json({
            error: 'Missing customer_data'
        });
    }

    const agency_book_via = customer_data.agency_book_via;
    const htl_bk_via = customer_data.htl_bk_via;

    const is_booked = (agency_book_via && agency_book_via !== '') ||
                     (htl_bk_via && htl_bk_via !== '');

    if (!is_booked) {
        return res.json({
            status: "not_booked",
            message: "Customer has not booked travel yet",
            action: "none"
        });
    }

    return res.json({
        status: "booked",
        message: "Customer is booked",
        booking_refs: {
            agency: agency_book_via || null,
            hotel: htl_bk_via || null
        },
        action: "ask_about_itinerary"
    });
}));

// =============================================================================
// MEMOS ENDPOINTS
// =============================================================================

/**
 * POST /api/memos/create
 * Create a new memo in RIMS_MEMOS
 */
app.post('/api/memos/create', asyncHandler(async (req, res) => {
    const { memo_type, details, vac_id, phone_number } = req.body;

    if (!memo_type || !vac_id) {
        return res.status(400).json({
            error: 'Missing required fields',
            required: ['memo_type', 'vac_id']
        });
    }

    const memo = {
        memo_type,
        details: details || '',
        vac_id,
        phone_number: phone_number || '',
        created_date: new Date().toISOString().split('T')[0],
        created_by: 'AI Agent'
    };

    // MOCK MODE
    if (USE_MOCK_DATA) {
        memo.id = Date.now();
        MOCK_MEMOS.push(memo);

        return res.json({
            success: true,
            message: 'Memo created successfully',
            memo_id: memo.id,
            memo
        });
    }

    // CASPIO MODE
    const result = await insertCaspioRecord(CASPIO_CONFIG.tables.rims_memos, memo);

    res.json({
        success: true,
        message: 'Memo created successfully',
        memo_id: result.id || Date.now(),
        memo: result
    });
}));

/**
 * GET /api/memos/:vac_id
 * Get all memos for a customer
 */
app.get('/api/memos/:vac_id', asyncHandler(async (req, res) => {
    const { vac_id } = req.params;

    // MOCK MODE
    if (USE_MOCK_DATA) {
        const memos = MOCK_MEMOS.filter(m => m.vac_id === vac_id);

        return res.json({
            vac_id,
            memo_count: memos.length,
            memos
        });
    }

    // CASPIO MODE
    const whereClause = `vac_id='${vac_id}'`;
    const memos = await queryCaspioTable(CASPIO_CONFIG.tables.rims_memos, whereClause);

    res.json({
        vac_id,
        memo_count: memos.length,
        memos
    });
}));

// =============================================================================
// HEALTH CHECK
// =============================================================================

app.get('/health', async (req, res) => {
    try {
        if (USE_MOCK_DATA) {
            return res.json({
                status: 'healthy',
                mode: 'mock',
                database: 'mock_rims_data',
                mock_customers: MOCK_RIMS_DATA.length,
                mock_packages: Object.keys(MOCK_KNOWLEDGE_BASE).length,
                timestamp: new Date().toISOString()
            });
        }

        // Test Caspio connection
        await getCaspioToken();

        res.json({
            status: 'healthy',
            mode: 'production',
            database: 'caspio',
            account: CASPIO_CONFIG.accountId,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            status: 'unhealthy',
            database: 'disconnected',
            error: error.message
        });
    }
});

// =============================================================================
// ERROR HANDLING
// =============================================================================

app.use((err, req, res, next) => {
    console.error('Error:', err);

    res.status(500).json({
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'production' ? 'An error occurred' : err.message
    });
});

// =============================================================================
// START SERVER
// =============================================================================

app.listen(PORT, () => {
    console.log(`\n🚀 Casablanca Express - RIMS API Server (Caspio)`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📍 Running on: http://localhost:${PORT}`);
    console.log(`📊 Mode: ${USE_MOCK_DATA ? 'MOCK DATA (Testing)' : 'PRODUCTION (Caspio Database)'}`);

    if (!USE_MOCK_DATA) {
        console.log(`🗄️  Caspio Account: ${CASPIO_CONFIG.accountId}`);
        console.log(`📋 Tables: ${Object.values(CASPIO_CONFIG.tables).join(', ')}`);
    }

    console.log(`\n📚 RIMS API Endpoints:`);
    console.log(`   GET  /health`);
    console.log(`   POST /api/rims/phone-lookup`);
    console.log(`   POST /api/rims/certificate-lookup`);
    console.log(`   GET  /api/kb/package/:certificate_code`);
    console.log(`   POST /api/logic/deposits-check`);
    console.log(`   POST /api/logic/travel-rep-check`);
    console.log(`   POST /api/logic/booking-check`);
    console.log(`   POST /api/memos/create`);
    console.log(`   GET  /api/memos/:vac_id`);

    if (USE_MOCK_DATA) {
        console.log(`\n🧪 Mock RIMS Test Data:`);
        console.log(`   Customers: ${MOCK_RIMS_DATA.length}`);
        MOCK_RIMS_DATA.forEach(c => {
            console.log(`   - ${c.first_name} ${c.last_name}: phn1=${c.phn1}, cert=${c.pkg_code2}, vac_id=${c.vac_id}`);
        });
        console.log(`   Knowledge Base: ${Object.keys(MOCK_KNOWLEDGE_BASE).length} package codes`);
    }
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, closing server...');
    process.exit(0);
});

module.exports = app;
